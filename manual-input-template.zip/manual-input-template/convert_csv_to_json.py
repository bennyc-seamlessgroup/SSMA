#!/usr/bin/env python3
import os
import csv
import json
import argparse
import sys

def to_int(val):
    if not val or val.strip() == "":
        return None
    try:
        return int(val.strip())
    except ValueError:
        return None

def to_float(val):
    if not val or val.strip() == "":
        return None
    try:
        return float(val.strip())
    except ValueError:
        return None

def to_bool(val):
    if not val or val.strip() == "":
        return None
    v = val.strip().lower()
    if v in ("true", "1", "yes"):
        return True
    if v in ("false", "0", "no"):
        return False
    return None

def read_csv_rows(filepath):
    if not os.path.exists(filepath):
        return []
    with open(filepath, mode='r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        return [row for row in reader]

def group_by_date(rows):
    groups = {}
    for r in rows:
        date = r.get("tradeDate")
        if not date:
            continue
        if date not in groups:
            groups[date] = []
        groups[date].append(r)
    return groups

def main():
    parser = argparse.ArgumentParser(description="Convert manual input CSV templates to JSON format.")
    parser.add_argument("--ticker", required=True, help="Stock ticker symbol (e.g. CURR)")
    parser.add_argument("--input-dir", default="manual-input-template", help="Directory containing input CSV files")
    parser.add_argument("--output-dir", default="data-sync-platform-centralized-v2/manual-input", help="Base directory for writing output JSONs")
    args = parser.parse_args()

    ticker = args.ticker
    input_dir = args.input_dir
    output_dir = args.output_dir

    print(f"Reading CSVs from: {input_dir}")
    print(f"Writing JSONs for Ticker: {ticker} to: {output_dir}")

    # Ensure output dir exists
    os.makedirs(output_dir, exist_ok=True)

    date_agnostic_functions = {
        "institutional-owner",
        "internal-float-inputs",
        "internal-float-inputs-ticker",
        "internal-float-inputs-user",
        "issued-share",
        "management-holdings",
        "profile",
        "sec-filings"
    }

    def write_json(function, ticker, trade_date, data):
        filename = "security-name" if function == "institutional-owner" else function
        if function in date_agnostic_functions:
            target_path = os.path.join(output_dir, function, ticker)
        else:
            target_path = os.path.join(output_dir, function, ticker, trade_date)
        
        os.makedirs(target_path, exist_ok=True)
        full_filepath = os.path.join(target_path, f"{filename}.json")
        
        with open(full_filepath, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2)
        print(f"  Saved: {full_filepath}")

    # 1. Profile
    profile_rows = read_csv_rows(os.path.join(input_dir, "profile.csv"))
    for row in profile_rows:
        trade_date = row.get("tradeDate")
        if not trade_date:
            continue
        
        generated_at = f"{trade_date}T23:59:00Z"
        data = {
            "schemaVersion": 1,
            "ticker": ticker,
            "tradeDate": trade_date,
            "generatedAt": generated_at,
            "companyName": row.get("companyName"),
            "stockCode": row.get("stockCode"),
            "_field_provenance": {
                "schemaVersion": "System Metadata",
                "ticker": "System Metadata",
                "generatedAt": "System Metadata",
                "companyName": "Manual Operations Input",
                "stockCode": "Manual Operations Input"
            }
        }
        write_json("profile", ticker, trade_date, data)

    # 2. Issued Share
    issued_rows = read_csv_rows(os.path.join(input_dir, "issued-share.csv"))
    for row in issued_rows:
        trade_date = row.get("tradeDate")
        if not trade_date:
            continue
        
        generated_at = f"{trade_date}T23:59:00Z"
        data = {
            "schemaVersion": 1,
            "ticker": ticker,
            "tradeDate": trade_date,
            "generatedAt": generated_at,
            "issuedShare": to_int(row.get("issuedShare")),
            "createdBy": "operations",
            "createdAt": generated_at,
            "updatedBy": "operations",
            "updatedAt": generated_at,
            "_field_provenance": {
                "issuedShare": "Manual Operations Input"
            }
        }
        write_json("issued-share", ticker, trade_date, data)

    # 3. Short Score
    score_rows = read_csv_rows(os.path.join(input_dir, "short-score.csv"))
    for row in score_rows:
        trade_date = row.get("tradeDate")
        if not trade_date:
            continue
        
        generated_at = f"{trade_date}T23:59:00Z"
        data = {
            "schemaVersion": 1,
            "ticker": ticker,
            "tradeDate": trade_date,
            "generatedAt": generated_at,
            "shortScore": to_float(row.get("shortScore")),
            "createdBy": "operations",
            "createdAt": generated_at,
            "updatedBy": "operations",
            "updatedAt": generated_at,
            "_field_provenance": {
                "shortScore": "Manual Operations Input"
            }
        }
        write_json("short-score", ticker, trade_date, data)

    # 5. Institutional Owner (security-name)
    io_rows = read_csv_rows(os.path.join(input_dir, "security-name.csv"))
    io_groups = group_by_date(io_rows)
    for trade_date, rows in io_groups.items():
        records = []
        generated_at = f"{trade_date}T23:59:00Z"
        for r in rows:
            records.append({
                "id": r.get("id"),
                "institutionalOwnerSecurityName": r.get("institutionalOwnerSecurityName"),
                "createdBy": "operations",
                "createdAt": generated_at
            })
        data = {
            "schemaVersion": 1,
            "ticker": ticker,
            "tradeDate": trade_date,
            "generatedAt": generated_at,
            "records": records,
            "_field_provenance": {
                "records": "Manual Operations Input"
            }
        }
        write_json("institutional-owner", ticker, trade_date, data)

    # 6. Management Holdings
    mgt_rows = read_csv_rows(os.path.join(input_dir, "management-holdings.csv"))
    mgt_groups = group_by_date(mgt_rows)
    for trade_date, rows in mgt_groups.items():
        records = []
        generated_at = f"{trade_date}T23:59:00Z"
        for r in rows:
            records.append({
                "id": r.get("id"),
                "holderName": r.get("holderName"),
                "category": r.get("category"),
                "action": r.get("action"),
                "shares": to_int(r.get("shares")),
                "percentOfShares": to_float(r.get("percentOfShares")),
                "fileDate": r.get("fileDate"),
                "effectiveDate": r.get("effectiveDate"),
                "form": r.get("form"),
                "showInOwnership": to_bool(r.get("showInOwnership")),
                "showAsSuggestion": to_bool(r.get("showAsSuggestion")),
                "autoApply": to_bool(r.get("autoApply")),
                "status": r.get("status"),
                "source": r.get("source"),
                "notes": r.get("notes"),
                "createdBy": "operations",
                "createdAt": generated_at,
                "updatedBy": "operations",
                "updatedAt": generated_at
            })
        data = {
            "schemaVersion": 1,
            "ticker": ticker,
            "tradeDate": trade_date,
            "generatedAt": generated_at,
            "records": records,
            "_field_provenance": {
                "records": "Manual Operations Input"
            }
        }
        write_json("management-holdings", ticker, trade_date, data)

    # 7. Internal Float Inputs
    if_rows = read_csv_rows(os.path.join(input_dir, "internal-float-inputs.csv"))
    if_groups = group_by_date(if_rows)
    for trade_date, rows in if_groups.items():
        generated_at = f"{trade_date}T23:59:00Z"

        strat_recs = []
        token_recs = []
        col_recs = []
        pf_data = {"shares": 0, "ratio": 0.0}

        for r in rows:
            section = r.get("section")
            if section == "managementStrategicHoldings":
                strat_recs.append({
                    "id": r.get("id"),
                    "holderName": r.get("holderName"),
                    "category": r.get("category"),
                    "shares": to_int(r.get("shares")),
                    "includeInDeduction": to_bool(r.get("includeInDeduction")),
                    "notes": r.get("notes"),
                    "createdBy": "operations",
                    "createdAt": generated_at,
                    "updatedBy": "operations",
                    "updatedAt": generated_at,
                    "deletedAt": None
                })
            elif section == "tokenizedShares":
                token_recs.append({
                    "id": r.get("id"),
                    "chain": r.get("chain"),
                    "provider": r.get("provider"),
                    "shares": to_int(r.get("shares")),
                    "createdBy": "operations",
                    "createdAt": generated_at,
                    "updatedBy": "operations",
                    "updatedAt": generated_at,
                    "deletedAt": None
                })
            elif section == "collateralizedShares":
                col_recs.append({
                    "id": r.get("id"),
                    "chain": r.get("chain"),
                    "protocol": r.get("protocol"),
                    "shares": to_int(r.get("shares")),
                    "createdBy": "operations",
                    "createdAt": generated_at,
                    "updatedBy": "operations",
                    "updatedAt": generated_at,
                    "deletedAt": None
                })
            elif section == "privateFriendlyHolders":
                pf_data = {
                    "shares": to_int(r.get("shares")) or 0,
                    "ratio": to_float(r.get("ratio")) or 0.0
                }

        # Auto-generate auditLog
        audit_log = []
        audit_counter = 1
        
        for r in rows:
            section = r.get("section")
            if section == "tokenizedShares":
                shares_val = to_int(r.get("shares")) or 0
                audit_log.append({
                    "id": f"audit-{audit_counter:03d}",
                    "action": "created",
                    "section": "tokenizedShares",
                    "recordId": r.get("id"),
                    "message": f"{shares_val:,} shares added to {r.get('chain')} / {r.get('provider')}.",
                    "createdBy": "operations",
                    "createdAt": generated_at,
                    "before": None,
                    "after": {
                        "shares": shares_val
                    }
                })
                audit_counter += 1
            elif section == "collateralizedShares":
                shares_val = to_int(r.get("shares")) or 0
                audit_log.append({
                    "id": f"audit-{audit_counter:03d}",
                    "action": "created",
                    "section": "collateralizedShares",
                    "recordId": r.get("id"),
                    "message": f"{shares_val:,} shares added to {r.get('chain')} / {r.get('protocol')}.",
                    "createdBy": "operations",
                    "createdAt": generated_at,
                    "before": None,
                    "after": {
                        "shares": shares_val
                    }
                })
                audit_counter += 1

        data = {
            "schemaVersion": 1,
            "ticker": ticker,
            "tradeDate": trade_date,
            "generatedAt": generated_at,
            "managementStrategicHoldings": {
                "records": strat_recs
            },
            "tokenizedShares": {
                "records": token_recs
            },
            "collateralizedShares": {
                "records": col_recs
            },
            "privateFriendlyHolders": pf_data,
            "auditLog": audit_log,
            "_field_provenance": {
                "all_fields": "Manual Customer Input"
            }
        }
        write_json("internal-float-inputs", ticker, trade_date, data)

    # 7b. Internal Float Inputs - Ticker Level
    ift_rows = read_csv_rows(os.path.join(input_dir, "internal-float-inputs-ticker.csv"))
    ift_groups = group_by_date(ift_rows)
    for trade_date, rows in ift_groups.items():
        generated_at = f"{trade_date}T23:59:00Z"
        token_recs = []
        col_recs = []
        for r in rows:
            section = r.get("section")
            if section == "tokenizedShares":
                token_recs.append({
                    "id": r.get("id"),
                    "chain": r.get("chain"),
                    "provider": r.get("provider"),
                    "shares": to_int(r.get("shares")),
                    "createdBy": "operations",
                    "createdAt": generated_at,
                    "updatedBy": "operations",
                    "updatedAt": generated_at,
                    "deletedAt": None
                })
            elif section == "collateralizedShares":
                col_recs.append({
                    "id": r.get("id"),
                    "chain": r.get("chain"),
                    "protocol": r.get("protocol"),
                    "shares": to_int(r.get("shares")),
                    "createdBy": "operations",
                    "createdAt": generated_at,
                    "updatedBy": "operations",
                    "updatedAt": generated_at,
                    "deletedAt": None
                })

        data = {
            "schemaVersion": 1,
            "ticker": ticker,
            "tradeDate": trade_date,
            "generatedAt": generated_at,
            "tokenizedShares": {"records": token_recs},
            "collateralizedShares": {"records": col_recs},
            "auditLog": [],
            "_field_provenance": {"all_fields": "Manual Customer Input"}
        }
        write_json("internal-float-inputs-ticker", ticker, trade_date, data)

    # 7c. Internal Float Inputs - User Level
    ifu_rows = read_csv_rows(os.path.join(input_dir, "internal-float-inputs-user.csv"))
    ifu_groups = group_by_date(ifu_rows)
    for trade_date, rows in ifu_groups.items():
        generated_at = f"{trade_date}T23:59:00Z"
        strat_recs = []
        pf_data = {"shares": 0, "ratio": 0.0}
        for r in rows:
            section = r.get("section")
            if section == "managementStrategicHoldings":
                strat_recs.append({
                    "id": r.get("id"),
                    "holderName": r.get("holderName"),
                    "category": r.get("category"),
                    "shares": to_int(r.get("shares")),
                    "includeInDeduction": to_bool(r.get("includeInDeduction")),
                    "notes": r.get("notes"),
                    "createdBy": "operations",
                    "createdAt": generated_at,
                    "updatedBy": "operations",
                    "updatedAt": generated_at,
                    "deletedAt": None
                })
            elif section == "privateFriendlyHolders":
                pf_data = {
                    "shares": to_int(r.get("shares")) or 0,
                    "ratio": to_float(r.get("ratio")) or 0.0
                }

        data = {
            "schemaVersion": 1,
            "ticker": ticker,
            "tradeDate": trade_date,
            "generatedAt": generated_at,
            "managementStrategicHoldings": {"records": strat_recs},
            "privateFriendlyHolders": pf_data,
            "auditLog": [],
            "_field_provenance": {"all_fields": "Manual Customer Input"}
        }
        write_json("internal-float-inputs-user", ticker, trade_date, data)

    # 8. Manual Availability
    avail_rows = read_csv_rows(os.path.join(input_dir, "manual-availability.csv"))
    for row in avail_rows:
        trade_date = row.get("tradeDate")
        if not trade_date:
            continue
        
        generated_at = f"{trade_date}T23:59:00Z"
        data = {
            "schemaVersion": 1,
            "ticker": ticker,
            "tradeDate": trade_date,
            "generatedAt": generated_at,
            "availableSharesIbkr": to_int(row.get("availableSharesIbkr")),
            "availableSharesFutu": to_int(row.get("availableSharesFutu")),
            "createdBy": "operations",
            "createdAt": generated_at,
            "updatedBy": "operations",
            "updatedAt": generated_at,
            "_field_provenance": {
                "availableSharesIbkr": "Manual Operations Input",
                "availableSharesFutu": "Manual Operations Input"
            }
        }
        write_json("manual-availability", ticker, trade_date, data)

    # 9. Utilization
    util_rows = read_csv_rows(os.path.join(input_dir, "utilization.csv"))
    for row in util_rows:
        trade_date = row.get("tradeDate")
        if not trade_date:
            continue
        
        generated_at = f"{trade_date}T23:59:00Z"
        data = {
            "schemaVersion": 1,
            "ticker": ticker,
            "tradeDate": trade_date,
            "generatedAt": generated_at,
            "utilizationPercent": to_float(row.get("utilizationPercent")),
            "createdBy": "operations",
            "createdAt": generated_at,
            "updatedBy": "operations",
            "updatedAt": generated_at,
            "_field_provenance": {
                "utilizationPercent": "Manual Operations Input"
            }
        }
        write_json("utilization", ticker, trade_date, data)

    # 10. SEC Filings
    sec_rows = read_csv_rows(os.path.join(input_dir, "sec-filings.csv"))
    sec_groups = group_by_date(sec_rows)
    for trade_date, rows in sec_groups.items():
        records = []
        generated_at = f"{trade_date}T23:59:00Z"
        for r in rows:
            records.append({
                "id": r.get("id"),
                "ticker": r.get("recordTicker") or ticker,
                "companyName": r.get("companyName"),
                "formType": r.get("formType"),
                "formDescription": r.get("formDescription"),
                "description": r.get("formDescription"),
                "filingDate": r.get("filingDate"),
                "reportingDate": r.get("reportingDate"),
                "act": r.get("act"),
                "filmNumber": r.get("filmNumber"),
                "fileNumber": r.get("fileNumber"),
                "accessionNumber": r.get("accessionNumber"),
                "filingsUrl": r.get("filingsUrl"),
                "notes": r.get("notes"),
                "createdBy": "operations",
                "createdAt": generated_at,
                "updatedBy": "operations",
                "updatedAt": generated_at
            })
        data = {
            "schemaVersion": 1,
            "ticker": ticker,
            "tradeDate": trade_date,
            "generatedAt": generated_at,
            "records": records,
            "_field_provenance": {
                "records": "Manual Operations Input"
            }
        }
        write_json("sec-filings", ticker, trade_date, data)

    # 11. Margins
    margin_rows = read_csv_rows(os.path.join(input_dir, "margins.csv"))
    for row in margin_rows:
        trade_date = row.get("tradeDate")
        if not trade_date:
            continue
        
        generated_at = f"{trade_date}T23:59:00Z"
        data = {
            "schemaVersion": 1,
            "ticker": ticker,
            "tradeDate": trade_date,
            "generatedAt": generated_at,
            "initialMarginIbkr": to_float(row.get("initialMarginIbkr")),
            "initialMarginFutu": to_float(row.get("initialMarginFutu")),
            "maintenanceMarginIbkr": to_float(row.get("maintenanceMarginIbkr")),
            "maintenanceMarginFutu": to_float(row.get("maintenanceMarginFutu")),
            "averageDurationDays": to_float(row.get("averageDurationDays")),
            "valueFormat": row.get("valueFormat") or "decimal_ratio",
            "displayFormat": row.get("displayFormat") or "percent",
            "createdBy": "operations",
            "createdAt": generated_at,
            "updatedBy": "operations",
            "updatedAt": generated_at,
            "_field_provenance": {
                "all_fields": "Manual Operations Input"
            }
        }
        write_json("margins", ticker, trade_date, data)

    print("CSV to JSON Conversion complete!")

if __name__ == "__main__":
    main()
