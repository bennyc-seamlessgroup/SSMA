# Manual Input CSV Templates & Conversion Guide

This folder contains CSV templates and a python conversion utility designed to simplify manual operations data entry for the AWS Data Downloading Platform.

## Directory Contents

| Template File | Manual Input Function | Type | Target Output JSON filename |
| :--- | :--- | :--- | :--- |
| `profile.csv` | `profile` | Date-Agnostic | `profile.json` |
| `issued-share.csv` | `issued-share` | Date-Agnostic | `issued-share.json` |
| `short-score.csv` | `short-score` | Date-Partitioned | `short-score.json` |
| `security-name.csv` | `institutional-owner` | Date-Agnostic | `security-name.json` |
| `management-holdings.csv` | `management-holdings` | Date-Agnostic | `management-holdings.json` |
| `internal-float-inputs.csv` | `internal-float-inputs` | Date-Agnostic | `internal-float-inputs.json` (Combined) |
| `internal-float-inputs-ticker.csv` | `internal-float-inputs-ticker` | Date-Agnostic | `internal-float-inputs-ticker.json` (Ticker-Level) |
| `manual-availability.csv` | `manual-availability` | Date-Partitioned | `manual-availability.json` |
| `utilization.csv` | `utilization` | Date-Partitioned | `utilization.json` |
| `sec-filings.csv` | `sec-filings` | Date-Agnostic | `sec-filings.json` |
| `margins.csv` | `margins` | Date-Partitioned | `margins.json` |

---

## Auto-Generated Metadata

For user convenience, system metadata, timestamps, and audit log tracking columns have been removed from the CSV templates. The conversion script automatically generates and injects these fields during compile time:
- `schemaVersion` is auto-set to `1`.
- `ticker` is dynamically injected into each JSON object using the `--ticker` CLI argument.
- `generatedAt`, `createdAt`, and `updatedAt` are auto-injected based on `tradeDate` (e.g., `{tradeDate}T23:59:00Z`).
- `createdBy` and `updatedBy` are defaulted to `"operations"`.
- `deletedAt` defaults to `null` where required.

---

## Output Path Convention

The platform organizes manual inputs into:
- **Date-Agnostic**: `manual-input/{function}/{ticker}/{filename}.json` (does not contain date partition in path)
- **Date-Partitioned**: `manual-input/{function}/{ticker}/{tradeDate}/{filename}.json`

The conversion utility automatically parses the records and directories according to these rules.

---

## How to Convert CSV to JSON

Use the included `convert_csv_to_json.py` script. The target `ticker` parameter is passed as a command-line argument to keep the template CSVs clean and focused on business data.

### Requirements
- Python 3.x (No external libraries required)

### Run the Script
Pass the target `--ticker` argument when calling the script:

```bash
python3 manual-input-template/convert_csv_to_json.py --ticker CURR
```

### Specifying Custom Paths
You can override the input directory or output destination using options:

```bash
python3 manual-input-template/convert_csv_to_json.py \
  --ticker CURR \
  --input-dir /path/to/my-csvs \
  --output-dir /path/to/output-jsons
```
